   <div>
      <span style="font-size: 16pt;color: #333333">Prescription </span>
      <button class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#addIn" style="margin-left: 2px;"><i class="fa fa-plus fa-fw"> </i>Upload Prescription</button> 
      </button></a>

    </div>